/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */package pei_teste;

import java.util.logging.Level;
import java.util.logging.Logger;
import pei_teste.ErrorHandlers.XpathNoResultsException;


/**
 *
 * @author Ricardo
 */
public class PEI_teste {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        XMLManagement teste = new XMLManagement("cd_catalog.xml","");
        
        
        teste.read(true);
        System.out.println(teste.validate(true));
      
        /*
        try {
                System.out.println(XpathEvaluator.applyXpathExpressionToString("/CATALOG/CD[COUNTRY=\"USA\"]",teste.getDocument()));
        } catch (XpathNoResultsException ex) {
            Logger.getLogger(PEI_teste.class.getName()).log(Level.SEVERE, null, ex);
        }*/
       
  
       
       XqueryEvaluator.execute("C:\\Users\\Ricardo\\Desktop\\ESTG\\2Ano\\PEI\\PEI_teste\\","Xquery.xqy");
       
       
        
        
                
    }
}
